<?php
session_destroy();
?>