<style>
    .main {
        min-height: calc(100vh - 56px - 66px);
    }
</style>