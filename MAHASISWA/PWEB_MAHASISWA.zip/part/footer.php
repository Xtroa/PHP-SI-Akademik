<div class="card bg-primary text-center" style="opacity: 0.5; position:relative; bottom:0; width:100%;">
  <div class="card-body bg-primary text-white text-center">
  WEBSITE MAHASISWA KAMPUS ©2020
  </div>
</div>