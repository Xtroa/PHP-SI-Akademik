<style>
    .main {
        min-height: calc(98vh - 56px - 66px);
    }
</style>