<div class="card bg-primary text-center" style="bottom: 0;width: 100%;">
  <div class="card-body bg-primary text-white text-center">
  CRUD ADMIN KAMPUS ©2020
  </div>
</div>